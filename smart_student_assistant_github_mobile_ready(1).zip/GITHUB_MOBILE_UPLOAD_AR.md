# Mobile GitHub Upload — مساعد الطالب الذكي

هذه النسخة مجهزة لرفع محتوياتها مباشرة داخل Repository من هاتفك.

## الرفع من الهاتف
1. أنشئ Repository فارغًا على GitHub.
2. افتح Add file ثم Upload files.
3. ارفع **محتويات هذا المجلد** وليس المجلد الأب نفسه.
4. تأكد أن pubspec.yaml وlib وbackend و.github موجودة في جذر Repository.
5. اضغط Commit changes.

## البناء
بعد الرفع، افتح تبويب Actions وشغّل Manual Release Build عند توفر Backend URL.

## الأمان
لا تضع API Key داخل Flutter أو داخل المستودع. ملف backend/.env.example مجرد نموذج للإعدادات.
